class Settings:
    SERVER_ADDRESS = "portfolio-correct-healthcare-actress.trycloudflare.com"

settings = Settings()