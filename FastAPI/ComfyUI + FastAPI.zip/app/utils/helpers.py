
def log_message(message: str):
    print(f"Log: {message}")